package kr.co.replates.entity;

import lombok.Data;

@Data
public class Stock {
	
	private int stock_Num;
	private int food_idx;
	private int game_idx;

}
